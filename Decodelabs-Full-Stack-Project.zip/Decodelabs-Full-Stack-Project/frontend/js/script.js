const root = document.documentElement;
const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const themeToggle = document.querySelector(".theme-toggle");
const form = document.querySelector("#contact-form");

const savedTheme = localStorage.getItem("digitalcraft-theme");
if (savedTheme === "dark") root.dataset.theme = "dark";

menuToggle?.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
    menuToggle?.setAttribute("aria-label", "Open menu");
  });
});

themeToggle?.addEventListener("click", () => {
  const dark = root.dataset.theme !== "dark";
  if (dark) {
    root.dataset.theme = "dark";
    localStorage.setItem("digitalcraft-theme", "dark");
  } else {
    delete root.dataset.theme;
    localStorage.setItem("digitalcraft-theme", "light");
  }
});

const fields = {
  name: {
    input: document.querySelector("#name"),
    error: document.querySelector("#name-error"),
    message: "Please enter your name."
  },
  email: {
    input: document.querySelector("#email"),
    error: document.querySelector("#email-error"),
    message: "Please enter a valid email."
  },
  message: {
    input: document.querySelector("#message"),
    error: document.querySelector("#message-error"),
    message: "Please enter a message."
  }
};

function validateField(field) {
  const value = field.input.value.trim();
  let valid = value.length > 0;

  if (field.input.type === "email") {
    valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  field.error.textContent = valid ? "" : field.message;
  field.input.setAttribute("aria-invalid", String(!valid));
  return valid;
}

Object.values(fields).forEach(field => {
  field.input.addEventListener("blur", () => validateField(field));
});

form?.addEventListener("submit", event => {
  event.preventDefault();
  const valid = Object.values(fields).map(validateField).every(Boolean);
  const status = document.querySelector("#form-status");

  if (!valid) {
    status.textContent = "Please fix the highlighted fields.";
    return;
  }

  const payload = {
    name: fields.name.input.value.trim(),
    email: fields.email.input.value.trim(),
    message: fields.message.input.value.trim()
  };

  try {
    const response = await fetch("/api/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await response.json();

    if (!response.ok) throw new Error(data.message || "Unable to send message.");

    status.textContent = data.message;
    form.reset();
    Object.values(fields).forEach(field => field.input.setAttribute("aria-invalid", "false"));
  } catch (error) {
    status.textContent = error.message || "Server error. Please try again.";
  }
});

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", event => {
    const target = document.querySelector(anchor.getAttribute("href"));
    if (!target) return;
    event.preventDefault();
    target.scrollIntoView({ behavior: "smooth", block: "start" });
  });
});


// Load portfolio projects from the Express API.
async function loadProjects() {
  const cards = document.querySelectorAll(".project-card");
  if (!cards.length) return;

  try {
    const response = await fetch("/api/projects");
    if (!response.ok) return;
    const projects = await response.json();

    projects.slice(0, cards.length).forEach((project, index) => {
      const card = cards[index];
      const info = card.querySelector(".project-info");
      if (!info) return;
      info.querySelector("span").textContent = project.title;
      info.querySelector("small").textContent = project.category;
    });
  } catch {
    // Static fallback content remains visible if the API is unavailable.
  }
}

loadProjects();
