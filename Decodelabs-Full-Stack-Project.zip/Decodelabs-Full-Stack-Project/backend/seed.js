require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("./config/db");
const Project = require("./models/Project");

const projects = [
  {
    title: "Future Objects",
    category: "Product landing page",
    description: "Responsive product experience.",
    featured: true
  },
  {
    title: "Ideas in Motion",
    category: "Editorial interface",
    description: "Editorial layout using CSS Grid.",
    featured: true
  },
  {
    title: "Build Better",
    category: "Creative studio",
    description: "Accessible creative studio interface.",
    featured: true
  }
];

(async () => {
  try {
    await connectDB();
    await Project.deleteMany({});
    await Project.insertMany(projects);
    console.log("Projects seeded successfully.");
  } catch (error) {
    console.error(error);
  } finally {
    await mongoose.connection.close();
  }
})();
