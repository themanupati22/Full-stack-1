const express = require("express");
const Contact = require("../models/Contact");

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { name, email, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ message: "Name, email and message are required." });
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      return res.status(400).json({ message: "Please provide a valid email address." });
    }

    const contact = await Contact.create({ name, email, message });

    res.status(201).json({
      message: "Your message has been received successfully.",
      id: contact._id
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not save your message." });
  }
});

router.get("/", async (_req, res) => {
  try {
    const messages = await Contact.find().sort({ createdAt: -1 }).lean();
    res.json(messages);
  } catch (error) {
    res.status(500).json({ message: "Could not load messages." });
  }
});

module.exports = router;
