const express = require("express");
const Project = require("../models/Project");

const router = express.Router();

router.get("/", async (_req, res) => {
  try {
    const projects = await Project.find().sort({ createdAt: -1 }).lean();
    res.json(projects);
  } catch (error) {
    res.status(500).json({ message: "Could not load projects." });
  }
});

router.post("/", async (req, res) => {
  try {
    const { title, category, description, featured } = req.body;

    if (!title || !category) {
      return res.status(400).json({ message: "Title and category are required." });
    }

    const project = await Project.create({
      title,
      category,
      description,
      featured: Boolean(featured)
    });

    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ message: "Could not create project." });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const deleted = await Project.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: "Project not found." });
    res.json({ message: "Project deleted." });
  } catch (error) {
    res.status(500).json({ message: "Could not delete project." });
  }
});

module.exports = router;
