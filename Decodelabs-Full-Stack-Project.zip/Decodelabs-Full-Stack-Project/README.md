# Decodelabs Project 1 — Full-Stack Responsive Interface

This repository turns the Project 1 responsive-interface brief into a **working full-stack web application**.

The training brief emphasizes responsive design, semantic HTML5, CSS Grid, Flexbox, vanilla JavaScript, mobile-first implementation, fluid typography and accessibility. This project keeps those frontend requirements and adds a real Express + MongoDB backend so the submission is genuinely full stack.

## Stack

### Frontend
- HTML5
- CSS3
- CSS Grid
- Flexbox
- Vanilla JavaScript
- Responsive/mobile-first layout
- Light/dark theme
- Client-side validation

### Backend
- Node.js
- Express
- REST API
- MongoDB
- Mongoose
- dotenv
- CORS

## Features

1. Responsive portfolio/studio website
2. Mobile navigation
3. Dark/light theme saved in browser
4. Responsive project showcase
5. Project data loaded from MongoDB through `/api/projects`
6. Contact form validation
7. Contact form saved to MongoDB through `/api/contact`
8. Contact-message API for future admin dashboard
9. Project create/delete APIs for future admin dashboard
10. Health endpoint at `/api/health`
11. Express serves the frontend and API from one application

## Folder structure

```text
Decodelabs-Full-Stack-Project/
├── frontend/
│   ├── index.html
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── script.js
│   └── assets/
├── backend/
│   ├── config/
│   │   └── db.js
│   ├── models/
│   │   ├── Contact.js
│   │   └── Project.js
│   ├── routes/
│   │   ├── contact.js
│   │   └── projects.js
│   ├── .env.example
│   ├── package.json
│   └── server.js
├── .gitignore
└── README.md
```

## Run locally

### 1. Install Node.js

Use a current LTS version.

### 2. Install backend packages

```bash
cd backend
npm install
```

### 3. Configure MongoDB

Copy:

```text
backend/.env.example
```

to:

```text
backend/.env
```

For local MongoDB:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/decodelabs
```

For MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string.

### 4. Start

```bash
npm start
```

Then open:

```text
http://localhost:5000
```

## API

### Health

```http
GET /api/health
```

### Projects

```http
GET /api/projects
POST /api/projects
DELETE /api/projects/:id
```

Example POST body:

```json
{
  "title": "Responsive Product Interface",
  "category": "Product",
  "description": "A mobile-first product experience.",
  "featured": true
}
```

### Contact

```http
GET /api/contact
POST /api/contact
```

Example POST body:

```json
{
  "name": "Sri Kiran",
  "email": "hello@example.com",
  "message": "I want to build a responsive web application."
}
```

## GitHub

```bash
git init
git add .
git commit -m "Build full stack responsive project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

### Important

Do **not** upload your real `backend/.env` file to GitHub. It is ignored by `.gitignore`. Upload only `.env.example`.

## Suggested next full-stack extension

The API is intentionally structured so an admin dashboard can be added later for:
- viewing contact messages
- changing message status
- adding/editing/removing portfolio projects
- authentication and protected admin routes
